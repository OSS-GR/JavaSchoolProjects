import java.util.Date;

public class LED extends ComputerMonitor {

}