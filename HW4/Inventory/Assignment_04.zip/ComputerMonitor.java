import java.util.Date;

public abstract class ComputerMonitor extends Screen {

}
