import java.util.Date;

public class SmartTV extends Screen {

}