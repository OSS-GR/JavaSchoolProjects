import java.util.Date;

public class CRT extends ComputerMonitor {

}