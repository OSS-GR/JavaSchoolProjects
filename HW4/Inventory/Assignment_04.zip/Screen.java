import java.util.Date;

public abstract class Screen {

}